from script_gen import generate_script
from voiceover_gen import generate_voiceover
from video_gen import make_video
from subtitle_gen import generate_subtitled_video
from tiktok_upload import upload_to_tiktok

import random

topics = [
    "The Pope conspiracy: The Vatican and its secrets",
    "The Alien conspiracy: Are we being visited by extraterrestrials?",
    "What trends are controlling society today?",
    "The brainrot caused by social media",
    "How TikTok rewires your brain"
]

topic = random.choice(topics)
print(f"Generating video for topic: {topic}")

script = generate_script(topic)
generate_voiceover(script)
make_video("voiceover.mp3", "stock_clip.mp4")

generate_subtitled_video("voiceover.mp3", "final.mp4", "final_with_subs.mp4")
upload_to_tiktok("final_with_subs.mp4", caption=topic)
